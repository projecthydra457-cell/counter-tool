document.addEventListener("DOMContentLoaded", function () {
    const textInput = document.getElementById("text-input");
    const wordCountDisplay = document.getElementById("word-count");
    const charCountWithDisplay = document.getElementById("char-count-with");
    const charCountWithoutDisplay = document.getElementById("char-count-without");
    const lineCountDisplay = document.getElementById("line-count");
    const paragraphCountDisplay = document.getElementById("paragraph-count");
    const readingTimeDisplay = document.getElementById("reading-time");
    const copyButton = document.getElementById("copy-button");
    const clearButton = document.getElementById("clear-button");

    textInput.addEventListener("input", updateCounts);

    function updateCounts() {
        const text = textInput.value;
        // Match words (split on whitespace, ignore empty)
        const words = text.match(/\b\S+\b/g) || [];
        // Count lines (include even empty ones if text is not empty)
        const lines = text.length ? text.split("\n") : [];
        // Paragraphs: split on two or more newlines and filter out empty paragraphs
        const paragraphs = text.trim().split(/\n{2,}/).filter(paragraph => paragraph.replace(/\s/g, '').length > 0);

        const wordCount = words.length;
        const charCountWith = text.length;
        const charCountWithout = text.replace(/\s/g, "").length;
        const lineCount = lines.length;
        const paragraphCount = text.length ? paragraphs.length : 0;
        // Estimated reading time: 200 words/minute, at least 1 min if any words
        const readingTime = wordCount ? Math.max(1, Math.ceil(wordCount / 200)) : 0;

        wordCountDisplay.textContent = wordCount;
        charCountWithDisplay.textContent = charCountWith;
        charCountWithoutDisplay.textContent = charCountWithout;
        lineCountDisplay.textContent = lineCount;
        paragraphCountDisplay.textContent = paragraphCount;
        readingTimeDisplay.textContent = readingTime;
    }

    copyButton.addEventListener("click", () => {
        textInput.select();
        document.execCommand("copy");
        alert("Text copied to clipboard!");
    });

    clearButton.addEventListener("click", () => {
        textInput.value = "";
        updateCounts();
        textInput.focus();
    });

    // Initial update
    updateCounts();
});